import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsofservices',
  templateUrl: './termsofservices.component.html',
  styleUrls: ['./termsofservices.component.css']
})
export class TermsofservicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
